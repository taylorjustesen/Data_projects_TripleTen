Hello Reviewer! 
Sorry about that! I thought the mockups were in the file but they must've not been. I added them as a new dashboard at the very end of my Tableau viz. Here is the updated link to view them. Thank you! 
Warm Regards,
Taylor Justesen 

Tableau Link - 
https://public.tableau.com/views/Sprint5ProjectSub1_17171772423390/ContianerMockups?:language=en-US&publish=yes&:sid=&:display_count=n&:origin=viz_share_link

Presentation Link - 
https://youtu.be/N2erP-79lVQ



